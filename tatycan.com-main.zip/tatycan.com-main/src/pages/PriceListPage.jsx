import PriceList from "../components/PriceList";

const PriceListPage = () => {
  return (
    <div className="pt-20">
      <PriceList />
    </div>
  );
};

export default PriceListPage;
